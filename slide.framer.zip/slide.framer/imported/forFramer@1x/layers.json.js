window.__imported__ = window.__imported__ || {};
window.__imported__["forFramer@1x/layers.json.js"] = [
	{
		"objectId": "D19A57A6-4A6E-4BC2-8BC4-85E4676A0A7A",
		"kind": "artboard",
		"name": "mainScreen",
		"originalName": "mainScreen",
		"maskFrame": null,
		"layerFrame": {
			"x": 236,
			"y": 5,
			"width": 750,
			"height": 1334
		},
		"visible": true,
		"metadata": {},
		"backgroundColor": "rgba(242, 242, 242, 1)",
		"children": [
			{
				"objectId": "347D4B5C-1554-43B0-A41B-BFDB764CD308",
				"kind": "group",
				"name": "stat",
				"originalName": "stat",
				"maskFrame": null,
				"layerFrame": {
					"x": 14,
					"y": 10,
					"width": 725,
					"height": 20
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-stat-mzq3rdrc.png",
					"frame": {
						"x": 14,
						"y": 10,
						"width": 725,
						"height": 20
					}
				},
				"children": [
					{
						"objectId": "462214AD-0DBD-4286-BD14-994712FCA956",
						"kind": "group",
						"name": "PhoneSignal",
						"originalName": "PhoneSignal",
						"maskFrame": null,
						"layerFrame": {
							"x": 14,
							"y": 10,
							"width": 194,
							"height": 20
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-PhoneSignal-ndyymje0.png",
							"frame": {
								"x": 14,
								"y": 10,
								"width": 194,
								"height": 20
							}
						},
						"children": [
							{
								"objectId": "87B20183-3265-40DB-99E7-CFB9050778EF",
								"kind": "group",
								"name": "Signal",
								"originalName": "Signal",
								"maskFrame": null,
								"layerFrame": {
									"x": 14,
									"y": 14,
									"width": 67,
									"height": 11
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Signal-oddcmjax.png",
									"frame": {
										"x": 14,
										"y": 14,
										"width": 67,
										"height": 11
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "83ADC3D2-7996-43E4-841F-0271305E9BC6",
						"kind": "group",
						"name": "Charge",
						"originalName": "Charge",
						"maskFrame": null,
						"layerFrame": {
							"x": 633,
							"y": 10,
							"width": 106,
							"height": 20
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-Charge-odnbremz.png",
							"frame": {
								"x": 633,
								"y": 10,
								"width": 106,
								"height": 20
							}
						},
						"children": [
							{
								"objectId": "69E1151C-EEC3-4509-BE00-093DA91E2FA1",
								"kind": "group",
								"name": "Battery_Icon",
								"originalName": "Battery Icon",
								"maskFrame": null,
								"layerFrame": {
									"x": 690,
									"y": 10,
									"width": 49,
									"height": 19
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-Battery_Icon-njlfmte1.png",
									"frame": {
										"x": 690,
										"y": 10,
										"width": 49,
										"height": 19
									}
								},
								"children": []
							}
						]
					}
				]
			},
			{
				"objectId": "956E0E9D-737C-4F4B-9783-BA0F30407CC4",
				"kind": "group",
				"name": "slideController",
				"originalName": "slideController",
				"maskFrame": null,
				"layerFrame": {
					"x": 0,
					"y": 274,
					"width": 751,
					"height": 972
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "DFDD2CD5-1BB2-4F50-A776-CD650AE4A39E",
						"kind": "group",
						"name": "slidePage9",
						"originalName": "slidePage9",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage9-rezerdjd.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "5A0AE1C6-95D7-4172-9009-E8257EE80D00",
						"kind": "group",
						"name": "slidePage8",
						"originalName": "slidePage8",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage8-nuewquux.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "8706AB39-5A68-4F02-9BAC-6E29991FC929",
						"kind": "group",
						"name": "slidePage7",
						"originalName": "slidePage7",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage7-odcwnkfc.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "DD3B23E0-DD73-4EDA-84F1-E995202168CB",
						"kind": "group",
						"name": "slidePage6",
						"originalName": "slidePage6",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage6-reqzqjiz.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "3306D175-A266-45C6-8662-1F44206C3D77",
						"kind": "group",
						"name": "slidePage5",
						"originalName": "slidePage5",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage5-mzmwnkqx.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "2C7B1C7E-2AF5-4684-BEDC-949A7068CC9D",
						"kind": "group",
						"name": "slidePage4",
						"originalName": "slidePage4",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage4-mkm3qjfd.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "8D476817-8233-4AEE-BF0A-62764EE07C93",
						"kind": "group",
						"name": "slidePage3",
						"originalName": "slidePage3",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage3-oeq0nzy4.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "A9A41F8E-4589-4214-8486-02DBBC39292E",
						"kind": "group",
						"name": "slidePage2",
						"originalName": "slidePage2",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage2-qtlbndfg.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "092F3A69-5E37-4CB4-B50E-3F3B36735182",
						"kind": "group",
						"name": "slidePage1",
						"originalName": "slidePage1",
						"maskFrame": null,
						"layerFrame": {
							"x": 1,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage1-mdkyrjnb.png",
							"frame": {
								"x": 1,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					},
					{
						"objectId": "2EF79BB0-889E-414E-9735-37DAD548E6CD",
						"kind": "group",
						"name": "slidePage0",
						"originalName": "slidePage0",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 274,
							"width": 750,
							"height": 972
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-slidePage0-mkvgnzlc.png",
							"frame": {
								"x": 0,
								"y": 274,
								"width": 750,
								"height": 972
							}
						},
						"children": []
					}
				]
			},
			{
				"objectId": "22B4D719-FD5F-4F6E-ACFF-124DAFECE3DF",
				"kind": "group",
				"name": "findScheme",
				"originalName": "findScheme",
				"maskFrame": null,
				"layerFrame": {
					"x": 749,
					"y": 0,
					"width": 751,
					"height": 1334
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-findScheme-mjjcneq3.png",
					"frame": {
						"x": 749,
						"y": 0,
						"width": 751,
						"height": 1334
					}
				},
				"children": []
			},
			{
				"objectId": "FEA5583E-676C-4ACA-8C08-411F2F8A6D2C",
				"kind": "group",
				"name": "storyScheme",
				"originalName": "storyScheme",
				"maskFrame": null,
				"layerFrame": {
					"x": -750,
					"y": 0,
					"width": 750,
					"height": 1334
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"image": {
					"path": "images/Layer-storyScheme-rkvbntu4.jpg",
					"frame": {
						"x": -750,
						"y": 0,
						"width": 750,
						"height": 1334
					}
				},
				"children": []
			},
			{
				"objectId": "E94C0ED8-CCE0-459F-9498-1CE8D67E8D54",
				"kind": "group",
				"name": "feedScheme",
				"originalName": "feedScheme",
				"maskFrame": null,
				"layerFrame": {
					"x": -2,
					"y": 0,
					"width": 6002,
					"height": 1334
				},
				"visible": true,
				"metadata": {
					"opacity": 1
				},
				"children": [
					{
						"objectId": "7CD99B7B-F2B6-4E9F-88EC-D22FE2000F4E",
						"kind": "group",
						"name": "navi",
						"originalName": "navi",
						"maskFrame": null,
						"layerFrame": {
							"x": -2,
							"y": 0,
							"width": 752,
							"height": 129
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "F0D67235-86F6-4E41-BEE7-6D9810D14663",
								"kind": "group",
								"name": "tab",
								"originalName": "tab",
								"maskFrame": null,
								"layerFrame": {
									"x": 257,
									"y": 56,
									"width": 238,
									"height": 68
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"children": [
									{
										"objectId": "B6F696CF-671C-4EAE-B336-CC77265184FA",
										"kind": "group",
										"name": "tabColorPad",
										"originalName": "tabColorPad",
										"maskFrame": {
											"x": 0,
											"y": 0,
											"width": 200,
											"height": 4
										},
										"layerFrame": {
											"x": 273,
											"y": 120,
											"width": 200,
											"height": 4
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"image": {
											"path": "images/Layer-tabColorPad-qjzgnjk2.png",
											"frame": {
												"x": 273,
												"y": 120,
												"width": 200,
												"height": 4
											}
										},
										"children": []
									},
									{
										"objectId": "C672A876-D2DF-4FD2-825D-ADD0A47812B3",
										"kind": "group",
										"name": "favGroup",
										"originalName": "favGroup",
										"maskFrame": null,
										"layerFrame": {
											"x": 257,
											"y": 56,
											"width": 83,
											"height": 53
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "A39D5184-2835-470F-AAC1-F022CA75A40B",
												"kind": "group",
												"name": "fav",
												"originalName": "fav",
												"maskFrame": null,
												"layerFrame": {
													"x": 257,
													"y": 56,
													"width": 83,
													"height": 53
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-fav-qtm5rdux.png",
													"frame": {
														"x": 257,
														"y": 56,
														"width": 83,
														"height": 53
													}
												},
												"children": []
											},
											{
												"objectId": "B2B0AAE8-EE7F-45BF-8A4F-9E287182670D",
												"kind": "group",
												"name": "favRegular",
												"originalName": "favRegular",
												"maskFrame": null,
												"layerFrame": {
													"x": 258,
													"y": 56,
													"width": 82,
													"height": 53
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-favRegular-qjjcmefb.png",
													"frame": {
														"x": 258,
														"y": 56,
														"width": 82,
														"height": 53
													}
												},
												"children": []
											}
										]
									},
									{
										"objectId": "F9B42B79-BB53-4732-A6AD-2A1FBED0EDDA",
										"kind": "group",
										"name": "hotGroup",
										"originalName": "hotGroup",
										"maskFrame": null,
										"layerFrame": {
											"x": 401,
											"y": 56,
											"width": 94,
											"height": 53
										},
										"visible": true,
										"metadata": {
											"opacity": 1
										},
										"children": [
											{
												"objectId": "7E6846EC-1E62-44EA-B61E-36641359EE41",
												"kind": "group",
												"name": "hot",
												"originalName": "hot",
												"maskFrame": null,
												"layerFrame": {
													"x": 401,
													"y": 56,
													"width": 94,
													"height": 53
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-hot-n0u2odq2.png",
													"frame": {
														"x": 401,
														"y": 56,
														"width": 94,
														"height": 53
													}
												},
												"children": []
											},
											{
												"objectId": "5A43D7F6-FD36-4776-8C20-99BD34D7DC97",
												"kind": "group",
												"name": "hotRegular",
												"originalName": "hotRegular",
												"maskFrame": null,
												"layerFrame": {
													"x": 401,
													"y": 56,
													"width": 94,
													"height": 53
												},
												"visible": true,
												"metadata": {
													"opacity": 1
												},
												"image": {
													"path": "images/Layer-hotRegular-nue0m0q3.png",
													"frame": {
														"x": 401,
														"y": 56,
														"width": 94,
														"height": 53
													}
												},
												"children": []
											}
										]
									}
								]
							},
							{
								"objectId": "7D7B0F08-834D-47FD-8D2C-5153E9785F77",
								"kind": "group",
								"name": "storyButton",
								"originalName": "storyButton",
								"maskFrame": null,
								"layerFrame": {
									"x": 22,
									"y": 56,
									"width": 56,
									"height": 56
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-storyButton-n0q3qjbg.png",
									"frame": {
										"x": 22,
										"y": 56,
										"width": 56,
										"height": 56
									}
								},
								"children": []
							},
							{
								"objectId": "0C2B1B93-87C9-457C-B13B-88625C93D762",
								"kind": "group",
								"name": "findButton",
								"originalName": "findButton",
								"maskFrame": null,
								"layerFrame": {
									"x": 673,
									"y": 55,
									"width": 56,
									"height": 56
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-findButton-memyqjfc.png",
									"frame": {
										"x": 673,
										"y": 55,
										"width": 56,
										"height": 56
									}
								},
								"children": []
							},
							{
								"objectId": "7A440601-FA16-4F9C-9728-BBA2D764366F",
								"kind": "group",
								"name": "naviBg",
								"originalName": "naviBg",
								"maskFrame": null,
								"layerFrame": {
									"x": -2,
									"y": 0,
									"width": 752,
									"height": 129
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-naviBg-n0e0nda2.png",
									"frame": {
										"x": -2,
										"y": 0,
										"width": 752,
										"height": 129
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "19D60197-1689-4A9C-AB17-00FE1A218494",
						"kind": "group",
						"name": "bottomBar",
						"originalName": "bottomBar",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 1245,
							"width": 750,
							"height": 89
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-bottomBar-mtlenjax.jpg",
							"frame": {
								"x": 0,
								"y": 1245,
								"width": 750,
								"height": 89
							}
						},
						"children": []
					},
					{
						"objectId": "D17E50CD-A304-482F-A8DE-818484286C02",
						"kind": "group",
						"name": "secondTab",
						"originalName": "secondTab",
						"maskFrame": null,
						"layerFrame": {
							"x": 750,
							"y": 129,
							"width": 751,
							"height": 84
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-secondTab-rde3rtuw.jpg",
							"frame": {
								"x": 750,
								"y": 129,
								"width": 751,
								"height": 84
							}
						},
						"children": [
							{
								"objectId": "0C92FB1A-B9AE-410B-A2AE-C5655BD4BFD7",
								"kind": "group",
								"name": "plus",
								"originalName": "plus",
								"maskFrame": null,
								"layerFrame": {
									"x": 1410,
									"y": 129,
									"width": 90,
									"height": 83
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-plus-mem5mkzc.png",
									"frame": {
										"x": 1410,
										"y": 129,
										"width": 90,
										"height": 83
									}
								},
								"children": []
							},
							{
								"objectId": "9A672838-9C3A-4E52-AC28-57D7C94B9346",
								"kind": "group",
								"name": "mask",
								"originalName": "mask",
								"maskFrame": null,
								"layerFrame": {
									"x": 750,
									"y": 129,
									"width": 30,
									"height": 82
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-mask-oue2nzi4.png",
									"frame": {
										"x": 750,
										"y": 129,
										"width": 30,
										"height": 82
									}
								},
								"children": []
							},
							{
								"objectId": "E14114A2-C298-4E93-9EE6-5B13ECC7800D",
								"kind": "group",
								"name": "secondTabBg",
								"originalName": "secondTabBg",
								"maskFrame": null,
								"layerFrame": {
									"x": 751,
									"y": 129,
									"width": 750,
									"height": 84
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-secondTabBg-rte0mte0.png",
									"frame": {
										"x": 751,
										"y": 129,
										"width": 750,
										"height": 84
									}
								},
								"children": []
							}
						]
					},
					{
						"objectId": "247516C7-7EEB-42D9-964D-2EF7C7A60F6C",
						"kind": "group",
						"name": "follow",
						"originalName": "follow",
						"maskFrame": null,
						"layerFrame": {
							"x": 0,
							"y": 129,
							"width": 750,
							"height": 1116
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"image": {
							"path": "images/Layer-follow-mjq3nte2.jpg",
							"frame": {
								"x": 0,
								"y": 129,
								"width": 750,
								"height": 1116
							}
						},
						"children": []
					},
					{
						"objectId": "8907F8B5-C026-42F1-865E-F726B4F01D0B",
						"kind": "group",
						"name": "hotFeed",
						"originalName": "hotFeed",
						"maskFrame": null,
						"layerFrame": {
							"x": 750,
							"y": 232,
							"width": 5250,
							"height": 1013
						},
						"visible": true,
						"metadata": {
							"opacity": 1
						},
						"children": [
							{
								"objectId": "76E3CF02-989B-4D06-81C9-2CA4DBD3301A",
								"kind": "group",
								"name": "espido",
								"originalName": "espido",
								"maskFrame": null,
								"layerFrame": {
									"x": 5250,
									"y": 232,
									"width": 750,
									"height": 1013
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-espido-nzzfm0ng.jpg",
									"frame": {
										"x": 5250,
										"y": 232,
										"width": 750,
										"height": 1013
									}
								},
								"children": []
							},
							{
								"objectId": "6DE7BA5C-E040-4BC4-A37A-0D62EACDEFF5",
								"kind": "group",
								"name": "movie",
								"originalName": "movie",
								"maskFrame": null,
								"layerFrame": {
									"x": 4500,
									"y": 232,
									"width": 750,
									"height": 1013
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-movie-nkrfn0jb.jpg",
									"frame": {
										"x": 4500,
										"y": 232,
										"width": 750,
										"height": 1013
									}
								},
								"children": []
							},
							{
								"objectId": "A666FE36-CA03-49C5-8952-E9B4A08A24C6",
								"kind": "group",
								"name": "social",
								"originalName": "social",
								"maskFrame": null,
								"layerFrame": {
									"x": 3750,
									"y": 232,
									"width": 750,
									"height": 1013
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-social-qty2nkzf.jpg",
									"frame": {
										"x": 3750,
										"y": 232,
										"width": 750,
										"height": 1013
									}
								},
								"children": []
							},
							{
								"objectId": "92AD794F-558F-43E8-9109-B673D9E4C402",
								"kind": "group",
								"name": "humor",
								"originalName": "humor",
								"maskFrame": null,
								"layerFrame": {
									"x": 3000,
									"y": 232,
									"width": 750,
									"height": 1013
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-humor-otjbrdc5.jpg",
									"frame": {
										"x": 3000,
										"y": 232,
										"width": 750,
										"height": 1013
									}
								},
								"children": []
							},
							{
								"objectId": "8346AE44-88F5-4AFC-90BA-A20DF3DD4B4A",
								"kind": "group",
								"name": "star",
								"originalName": "star",
								"maskFrame": null,
								"layerFrame": {
									"x": 2250,
									"y": 232,
									"width": 750,
									"height": 1013
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-star-odm0nkff.jpg",
									"frame": {
										"x": 2250,
										"y": 232,
										"width": 750,
										"height": 1013
									}
								},
								"children": []
							},
							{
								"objectId": "7B18AC51-502F-46E1-9A03-AAF5C6ED5D9D",
								"kind": "group",
								"name": "lbs",
								"originalName": "lbs",
								"maskFrame": null,
								"layerFrame": {
									"x": 1500,
									"y": 232,
									"width": 750,
									"height": 1013
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-lbs-n0ixoefd.jpg",
									"frame": {
										"x": 1500,
										"y": 232,
										"width": 750,
										"height": 1013
									}
								},
								"children": []
							},
							{
								"objectId": "C373FD7A-0B79-4585-B991-903CC2115C6C",
								"kind": "group",
								"name": "hot1",
								"originalName": "hot",
								"maskFrame": null,
								"layerFrame": {
									"x": 750,
									"y": 232,
									"width": 750,
									"height": 1013
								},
								"visible": true,
								"metadata": {
									"opacity": 1
								},
								"image": {
									"path": "images/Layer-hot-qzm3m0ze.jpg",
									"frame": {
										"x": 750,
										"y": 232,
										"width": 750,
										"height": 1013
									}
								},
								"children": []
							}
						]
					}
				]
			}
		]
	}
]